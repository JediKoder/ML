History
=======

0.2.5 (2016-05-30)
------------------

* Inclusion of cli in install
* many other minor changes since open-sourcing...

0.2.0 (2016-05-03)
------------------

* First opensource release to GitHub

0.1.0 (2016-04-29)
------------------

* Relatively stable version used by Zalando internally, prior to opensource release
