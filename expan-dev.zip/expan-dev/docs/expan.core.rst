expan.core package
==================

Submodules
----------

expan.core.binning module
-------------------------

.. automodule:: expan.core.binning
    :members:
    :undoc-members:
    :show-inheritance:

expan.core.debugging module
---------------------------

.. automodule:: expan.core.debugging
    :members:
    :undoc-members:
    :show-inheritance:

expan.core.experiment module
----------------------------

.. automodule:: expan.core.experiment
    :members:
    :undoc-members:
    :show-inheritance:

expan.core.experimentdata module
--------------------------------

.. automodule:: expan.core.experimentdata
    :members:
    :undoc-members:
    :show-inheritance:

expan.core.results module
-------------------------

.. automodule:: expan.core.results
    :members:
    :undoc-members:
    :show-inheritance:

expan.core.statistics module
----------------------------

.. automodule:: expan.core.statistics
    :members:
    :undoc-members:
    :show-inheritance:

expan.core.util module
----------------------

.. automodule:: expan.core.util
    :members:
    :undoc-members:
    :show-inheritance:

expan.core.version module
-------------------------

.. automodule:: expan.core.version
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: expan.core
    :members:
    :undoc-members:
    :show-inheritance:
