.. highlight:: shell

================
Related Projects
================

There may be alternative libraries providing similar functionality, and these
should be collected here. Very incomplete list so far...

- **abba** (https://github.com/thumbtack/abba)

	Mainly handles binomial distributions.

- **bootstrapped** (https://github.com/facebookincubator/bootstrapped)

	Calculates bootstrapped confidence intervals, with A/B test as an example.
