This is the directory to store all kinds of data fetchers/loaders, which
retrieve data from a certain source and convert it to an ExperimentData object.
One can implement fetchers for generic data formats (e.g. csv, hdf5), as well
as fetchers for some internal/proprietary data sources.