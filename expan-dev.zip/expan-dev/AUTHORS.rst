=======
Credits
=======

Development Lead
----------------

* Octopus McSquid <team-octopus@zalando.de>

Contributors
------------

* Grigory Bordyugov <grigory.bordyugov@zalando.de>
* Dominic Heger <dominic.heger@zalando.de>
* Jie Bao <jie.bao@zalando.de>
* Marko Kolarek <marko.kolarek@zalando.de>
* Robert Muil <robert.muil@zalando.de>
* Till Riffert <till.riffert@zalando.de>
